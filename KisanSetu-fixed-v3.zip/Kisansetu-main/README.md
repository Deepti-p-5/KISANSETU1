# KisanSetu

KisanSetu is a Next.js 15 + React 19 agricultural marketplace for equipment rental, labour hiring, agri supplies, bookings, messaging and payments.

## Requirements

- Node.js 20 or newer
- npm 10 or newer
- A Supabase project for authentication and database features

## Run locally

1. Open a terminal in the folder containing `package.json`.
2. Install dependencies:

```bash
npm install
```

3. Create `.env.local` from `.env.example` and add your Supabase credentials:

```bash
copy .env.example .env.local
```

On PowerShell, the same command is:

```powershell
Copy-Item .env.example .env.local
```

4. Run the database migrations in the `supabase/migrations` folder against your Supabase project (for example with the Supabase CLI), if the database is not already configured.

5. Start the development server:

```bash
npm run dev
```

6. Open:

http://localhost:4028

## Production build

```bash
npm run build
npm start
```

Then open:

http://localhost:4028

## Checks

```bash
npm run type-check
```

## Optional integrations

Razorpay, Stripe, Twilio and Resend environment variables are only needed for the corresponding payment, OTP and email features. Keep secret keys in `.env.local`; never commit them.

## Important

The project intentionally does not include real API keys or secrets. You must provide your own Supabase/payment/OTP credentials for those integrations.
